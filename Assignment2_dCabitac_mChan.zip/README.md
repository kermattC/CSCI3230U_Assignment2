CSCI 3230U - Assignment 2 - Web Services

Group Members:

Dominic Cabitac - 100547918
Matt Chan	- 100622178

